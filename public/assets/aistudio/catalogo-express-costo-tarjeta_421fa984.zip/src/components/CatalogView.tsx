import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  ArrowUpDown,
  Car,
  Train,
  Store,
  CreditCard,
  Percent,
  Check,
  AlertCircle,
} from 'lucide-react';
import { AppSettings, CatalogData, LogisticsMode, CardInstallmentPlan } from '../types';
import { ProductCard } from './ProductCard';
import { normalizeForSearch } from '../utils/textUtils';
import {
  calculateLogisticsCost,
  MERCADO_PAGO_RATES,
  getCardPlan,
} from '../utils/pricingUtils';

interface CatalogViewProps {
  catalog: CatalogData;
  settings: AppSettings;
  onUpdateSettings: (settings: AppSettings) => void;
}

export const CatalogView: React.FC<CatalogViewProps> = ({
  catalog,
  settings,
  onUpdateSettings,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedBrand, setSelectedBrand] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'original' | 'price_asc' | 'price_desc' | 'name_asc'>('original');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (text: string) => {
    setToastMessage(`Copiado: "${text}"`);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    const normalizedQuery = normalizeForSearch(searchTerm);

    return catalog.products
      .filter((prod) => {
        // Category filter
        if (selectedCategory !== 'ALL' && prod.category !== selectedCategory) {
          return false;
        }

        // Brand filter
        if (selectedBrand !== 'ALL' && prod.brand !== selectedBrand) {
          return false;
        }

        // Text search (name, brand, category)
        if (normalizedQuery) {
          const matchName = normalizeForSearch(prod.name).includes(normalizedQuery);
          const matchBrand = normalizeForSearch(prod.brand).includes(normalizedQuery);
          const matchCat = normalizeForSearch(prod.category).includes(normalizedQuery);
          const matchNote = prod.note ? normalizeForSearch(prod.note).includes(normalizedQuery) : false;

          if (!matchName && !matchBrand && !matchCat && !matchNote) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price_asc') return a.cashPrice - b.cashPrice;
        if (sortBy === 'price_desc') return b.cashPrice - a.cashPrice;
        if (sortBy === 'name_asc') return a.name.localeCompare(b.name, 'es');
        return a.originalRowNumber - b.originalRowNumber;
      });
  }, [catalog.products, searchTerm, selectedCategory, selectedBrand, sortBy]);

  // Counts per category
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    catalog.products.forEach((p) => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return counts;
  }, [catalog.products]);

  const currentLogisticsCost = calculateLogisticsCost(settings.logistics);
  const activePlan = getCardPlan(settings.selectedCardPlan);

  const handleSetLogisticsMode = (mode: LogisticsMode) => {
    onUpdateSettings({
      ...settings,
      logistics: {
        ...settings.logistics,
        mode,
      },
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 max-w-sm bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-lg border border-slate-800 text-xs flex items-center gap-2.5 animate-in slide-in-from-bottom duration-200">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="truncate">{toastMessage}</span>
        </div>
      )}

      {/* Quick Sales Bar (Logística + Plan MP en tiempo real) */}
      <div className="bg-white rounded-xl border border-slate-200 p-3 sm:p-4 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Logistics Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-semibold text-slate-700 flex items-center gap-1.5 shrink-0">
            <Car className="w-4 h-4 text-blue-600" />
            Traslado:
          </span>
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => handleSetLogisticsMode('car')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                settings.logistics.mode === 'car'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Auto</span>
              <span className="font-mono text-[11px] text-blue-700 font-bold">
                (${settings.logistics.carGasoline + settings.logistics.carParking})
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleSetLogisticsMode('metro')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                settings.logistics.mode === 'metro'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Train className="w-3 h-3 text-amber-600" />
              <span>Metro (${settings.logistics.metroCost})</span>
            </button>

            <button
              type="button"
              onClick={() => handleSetLogisticsMode('none')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md font-medium transition-colors ${
                settings.logistics.mode === 'none'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Store className="w-3 h-3 text-emerald-600" />
              <span>Sin traslado ($0)</span>
            </button>
          </div>
        </div>

        {/* Global Mercado Pago Plan */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-semibold text-slate-700 flex items-center gap-1.5 shrink-0">
            <CreditCard className="w-4 h-4 text-blue-600" />
            Terminal MP:
          </span>
          <select
            value={settings.selectedCardPlan}
            onChange={(e) =>
              onUpdateSettings({
                ...settings,
                selectedCardPlan: e.target.value as CardInstallmentPlan,
              })
            }
            className="px-2.5 py-1 bg-blue-50 border border-blue-200 rounded-lg text-xs font-bold text-blue-950 focus:outline-none focus:ring-1 focus:ring-blue-600 cursor-pointer"
          >
            {MERCADO_PAGO_RATES.map((rate) => (
              <option key={rate.id} value={rate.id}>
                {rate.label}
              </option>
            ))}
          </select>

          {/* Margin Status Indicator */}
          <span className="hidden md:inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-md text-[11px] font-semibold">
            <Percent className="w-3 h-3 text-emerald-600" />
            {settings.marginMode === 'tier' ? 'Margen Escalonado (7% - 10%)' : `Margen Fijo (${settings.manualMarginPercent}%)`}
          </span>
        </div>
      </div>

      {/* Search & Main Controls Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-4">
        {/* Row 1: Search Box + Brand + Sort + Mode */}
        <div className="flex flex-col md:flex-row gap-3">
          {/* Live Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por producto, marca (Intel, AMD, ASUS...) o categoría..."
              className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Controls: Brand, Sort, Mode */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Brand Filter */}
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer"
            >
              <option value="ALL">Todas las marcas ({catalog.brands.length})</option>
              {catalog.brands.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-transparent font-medium text-slate-800 focus:outline-none text-xs cursor-pointer"
              >
                <option value="original">Orden del proveedor</option>
                <option value="price_asc">Precio: Menor a Mayor</option>
                <option value="price_desc">Precio: Mayor a Menor</option>
                <option value="name_asc">Nombre: A - Z</option>
              </select>
            </div>

            {/* Display Price Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/60 text-xs">
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, priceDisplayMode: 'both' })}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  settings.priceDisplayMode === 'both'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Ambos
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, priceDisplayMode: 'cash' })}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  settings.priceDisplayMode === 'cash'
                    ? 'bg-white text-emerald-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Efectivo
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ ...settings, priceDisplayMode: 'card' })}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  settings.priceDisplayMode === 'card'
                    ? 'bg-white text-blue-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Tarjeta ({activePlan.shortLabel})
              </button>
            </div>
          </div>
        </div>

        {/* Row 2: Category Filter Horizontal Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 scrollbar-thin">
          <button
            type="button"
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              selectedCategory === 'ALL'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>Todas</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                selectedCategory === 'ALL'
                  ? 'bg-slate-800 text-slate-200'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              {catalog.products.length}
            </span>
          </button>

          {catalog.categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{cat}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                  selectedCategory === cat
                    ? 'bg-slate-800 text-slate-200'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {categoryCounts[cat] || 0}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Catalog Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
        <span>
          Mostrando <strong className="text-slate-800">{filteredProducts.length}</strong> de{' '}
          {catalog.products.length} productos disponibles
        </span>

        {(searchTerm || selectedCategory !== 'ALL' || selectedBrand !== 'ALL') && (
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('ALL');
              setSelectedBrand('ALL');
            }}
            className="text-blue-700 hover:text-blue-900 underline underline-offset-2"
          >
            Limpiar filtros
          </button>
        )}
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              settings={settings}
              onCopied={showToast}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center max-w-md mx-auto space-y-3">
          <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-base font-semibold text-slate-900">
            No se encontraron productos
          </h3>
          <p className="text-xs text-slate-500">
            No hay productos que coincidan con &ldquo;{searchTerm}&rdquo; o los filtros seleccionados.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('ALL');
              setSelectedBrand('ALL');
            }}
            className="px-4 py-2 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Restablecer todos los filtros
          </button>
        </div>
      )}
    </div>
  );
};
