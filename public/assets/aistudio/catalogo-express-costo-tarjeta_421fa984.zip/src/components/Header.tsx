import React from 'react';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Settings,
  Bug,
  Calendar,
  Layers,
  ArrowRightLeft,
  EyeOff,
} from 'lucide-react';
import { AppSettings, CatalogData } from '../types';
import { calculateLogisticsCost, getCardPlan } from '../utils/pricingUtils';

interface HeaderProps {
  catalog: CatalogData | null;
  activeTab: 'catalog' | 'changes' | 'omitted';
  setActiveTab: (tab: 'catalog' | 'changes' | 'omitted') => void;
  changesCount: number;
  onOpenSettings: () => void;
  onOpenUpload: () => void;
  onOpenDebug: () => void;
  onExportExcel: () => void;
  isExporting: boolean;
  settings: AppSettings;
}

export const Header: React.FC<HeaderProps> = ({
  catalog,
  activeTab,
  setActiveTab,
  changesCount,
  onOpenSettings,
  onOpenUpload,
  onOpenDebug,
  onExportExcel,
  isExporting,
  settings,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Bar Contract: Zone 1 (Brand) — Zone 2 (Nav Tabs) — Zone 3 (Actions) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('catalog')}
              className="flex items-center gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-900 rounded-lg p-1"
            >
              <div className="w-9 h-9 rounded-lg bg-slate-900 text-white flex items-center justify-center shadow-xs">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <span className="text-base font-bold tracking-tight text-slate-900 block leading-tight">
                  Catálogo Express
                </span>
                <span className="text-xs text-slate-500 font-medium hidden sm:block">
                  Visor de Precios
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links / Primary Tabs */}
          {catalog && (
            <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-1 scrollbar-none">
              <button
                onClick={() => setActiveTab('catalog')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'catalog'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Catálogo</span>
                <span
                  className={`text-xs px-1.5 py-0.2 rounded-md ${
                    activeTab === 'catalog'
                      ? 'bg-slate-800 text-slate-200'
                      : 'bg-slate-200/80 text-slate-700'
                  }`}
                >
                  {catalog.products.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('changes')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'changes'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>Cambios</span>
                {changesCount > 0 && (
                  <span
                    className={`text-xs px-1.5 py-0.2 rounded-md font-semibold ${
                      activeTab === 'changes'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {changesCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('omitted')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'omitted'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <EyeOff className="w-4 h-4" />
                <span>Omitidos</span>
                <span
                  className={`text-xs px-1.5 py-0.2 rounded-md ${
                    activeTab === 'omitted'
                      ? 'bg-rose-900 text-rose-200'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {catalog.omitted.length}
                </span>
              </button>
            </nav>
          )}

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {catalog && (
              <>
                <button
                  onClick={onOpenDebug}
                  title="Verificar colores y celdas de las primeras 30 filas"
                  className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                  aria-label="Diagnóstico de colores"
                >
                  <Bug className="w-4 h-4" />
                </button>

                <button
                  onClick={onOpenSettings}
                  title="Configurar gastos de traslado, margen y tasas de Mercado Pago"
                  className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs sm:text-sm font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                >
                  <Settings className="w-4 h-4 text-slate-500" />
                  <span className="hidden md:inline">
                    {settings.logistics.mode === 'none'
                      ? 'Sin traslado'
                      : `Logística +$${calculateLogisticsCost(settings.logistics)}`}
                  </span>
                  <span className="hidden lg:inline text-emerald-700 font-semibold">
                    · {settings.marginMode === 'tier' ? 'Margen Auto' : `${settings.manualMarginPercent}%`}
                  </span>
                </button>

                <button
                  onClick={onExportExcel}
                  disabled={isExporting}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg shadow-xs transition-colors whitespace-nowrap"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Exportar Excel</span>
                  <span className="sm:hidden">Excel</span>
                </button>
              </>
            )}

            <button
              onClick={onOpenUpload}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                catalog
                  ? 'text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200'
                  : 'text-white bg-slate-900 hover:bg-slate-800 shadow-xs'
              }`}
            >
              <Upload className="w-4 h-4" />
              <span>{catalog ? 'Nueva Lista' : 'Subir Excel'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sub-strip with Metadata when Catalog is active */}
      {catalog && (
        <div className="bg-slate-50 border-t border-slate-200/80 px-4 sm:px-6 lg:px-8 py-1.5 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-y-1 gap-x-4">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 font-medium text-slate-800">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              Fecha de la lista: {catalog.listDate}
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="truncate max-w-[200px] sm:max-w-xs text-slate-500" title={catalog.fileName}>
              {catalog.fileName}
            </span>
          </div>

          <div className="flex items-center gap-3 tabular-nums">
            <span className="text-emerald-700 font-medium">
              {catalog.products.length} disponibles
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="text-rose-600 font-medium">
              {catalog.omitted.length} omitidos
            </span>
            {catalog.products.filter((p) => p.needsVerification).length > 0 && (
              <>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="text-amber-700 font-medium">
                  {catalog.products.filter((p) => p.needsVerification).length} por verificar
                </span>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
