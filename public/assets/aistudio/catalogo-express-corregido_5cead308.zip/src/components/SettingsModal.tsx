import React from 'react';
import { X, CreditCard, Percent, MessageCircle, HelpCircle } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}) => {
  if (!isOpen) return null;

  const [localSettings, setLocalSettings] = React.useState<AppSettings>({ ...settings });

  const handleSave = () => {
    onSaveSettings(localSettings);
    onClose();
  };

  const surchargePresets = [1.5, 2.0, 2.5, 3.0, 3.5, 4.0];
  const marginPresets = [0, 5, 10, 15, 20, 25];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Ajustes de Precios y Cotización</h2>
              <p className="text-xs text-slate-500">Configura recargos, márgenes y formato para WhatsApp</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Card Surcharge Setting */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-600" />
                Recargo por Pago con Tarjeta (%)
              </label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="20"
                  value={localSettings.cardSurchargePercent}
                  onChange={(e) =>
                    setLocalSettings({
                      ...localSettings,
                      cardSurchargePercent: Math.max(0, parseFloat(e.target.value) || 0),
                    })
                  }
                  className="w-20 px-2 py-1 text-right font-mono text-sm font-bold border border-slate-300 rounded-md focus:ring-2 focus:ring-slate-900 focus:outline-none"
                />
                <span className="text-sm font-semibold text-slate-600">%</span>
              </div>
            </div>

            <p className="text-xs text-slate-500">
              Por defecto el proveedor aplica 2.0% (=C*1.02). Este porcentaje recalcula en vivo el precio con tarjeta en todo el catálogo.
            </p>

            {/* Presets */}
            <div className="flex flex-wrap gap-2 pt-1">
              {surchargePresets.map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() =>
                    setLocalSettings({ ...localSettings, cardSurchargePercent: pct })
                  }
                  className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors ${
                    localSettings.cardSurchargePercent === pct
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {pct.toFixed(1)}%
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-200 pt-5 space-y-3">
            {/* Profit Margin Setting */}
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <Percent className="w-4 h-4 text-emerald-600" />
                  Margen de Ganancia Opcional (%)
                </label>
                <span className="text-xs text-slate-500">
                  Calcula tu &ldquo;Precio de Venta Sugerido&rdquo; sobre el precio de costo
                </span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="100"
                  value={localSettings.profitMarginPercent}
                  onChange={(e) =>
                    setLocalSettings({
                      ...localSettings,
                      profitMarginPercent: Math.max(0, parseFloat(e.target.value) || 0),
                    })
                  }
                  className="w-20 px-2 py-1 text-right font-mono text-sm font-bold border border-slate-300 rounded-md focus:ring-2 focus:ring-slate-900 focus:outline-none"
                />
                <span className="text-sm font-semibold text-slate-600">%</span>
              </div>
            </div>

            {/* Presets */}
            <div className="flex flex-wrap gap-2 pt-1">
              {marginPresets.map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() =>
                    setLocalSettings({ ...localSettings, profitMarginPercent: pct })
                  }
                  className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors ${
                    localSettings.profitMarginPercent === pct
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {pct === 0 ? '0% (Solo Costo)' : `+${pct}%`}
                </button>
              ))}
            </div>

            {localSettings.profitMarginPercent > 0 && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-900">
                <span className="font-semibold block mb-0.5">Fórmula aplicada:</span>
                Precio Venta = Precio Efectivo × (1 + {localSettings.profitMarginPercent}%)
              </div>
            )}
          </div>

          <div className="border-t border-slate-200 pt-5 space-y-3">
            {/* WhatsApp Format Selection */}
            <label className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              Estilo de Copia para WhatsApp
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setLocalSettings({ ...localSettings, whatsAppFormat: 'compact' })}
                className={`p-3 text-left rounded-lg border text-xs transition-all ${
                  localSettings.whatsAppFormat === 'compact'
                    ? 'border-slate-900 bg-slate-50 ring-1 ring-slate-900'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span className="font-semibold text-slate-900 block mb-1">
                  Una sola línea (Rápida)
                </span>
                <span className="text-slate-500 font-mono text-[11px] block bg-white p-1.5 rounded border border-slate-200">
                  Ryzen 5 7600 — $3,450.00 efvo / $3,519.00 tarjeta
                </span>
              </button>

              <button
                type="button"
                onClick={() => setLocalSettings({ ...localSettings, whatsAppFormat: 'detailed' })}
                className={`p-3 text-left rounded-lg border text-xs transition-all ${
                  localSettings.whatsAppFormat === 'detailed'
                    ? 'border-slate-900 bg-slate-50 ring-1 ring-slate-900'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span className="font-semibold text-slate-900 block mb-1">
                  Estructurada con Viñetas
                </span>
                <span className="text-slate-500 font-mono text-[10px] block bg-white p-1.5 rounded border border-slate-200 whitespace-pre-line">
                  *Ryzen 5 7600*{'\n'}💵 Efvo: $3,450.00 | 💳 Tarjeta: $3,519.00
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 bg-slate-50 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors"
          >
            Guardar Ajustes
          </button>
        </div>
      </div>
    </div>
  );
};
