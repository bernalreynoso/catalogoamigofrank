import React, { useState } from 'react';
import { Copy, Check, AlertTriangle, MessageSquare, CreditCard, Banknote, Sparkles } from 'lucide-react';
import { AppSettings, CatalogProduct } from '../types';
import { formatCurrency } from '../utils/textUtils';

interface ProductCardProps {
  product: CatalogProduct;
  settings: AppSettings;
  onCopied: (text: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  settings,
  onCopied,
}) => {
  const [copied, setCopied] = useState(false);

  const cardMultiplier = 1 + settings.cardSurchargePercent / 100;
  const cardPrice = product.cashPrice * cardMultiplier;

  const marginMultiplier = 1 + settings.profitMarginPercent / 100;
  const sellingPrice = product.cashPrice * marginMultiplier;
  const sellingCardPrice = cardPrice * marginMultiplier;

  const getWhatsAppMessage = (): string => {
    const cashStr = formatCurrency(settings.profitMarginPercent > 0 ? sellingPrice : product.cashPrice);
    const cardStr = formatCurrency(settings.profitMarginPercent > 0 ? sellingCardPrice : cardPrice);

    if (settings.whatsAppFormat === 'detailed') {
      let msg = `*${product.name}*\n💵 Efectivo/Transf: ${cashStr}\n💳 Tarjeta (${settings.cardSurchargePercent}%): ${cardStr}`;
      if (product.note) {
        msg += `\n📌 Nota: ${product.note}`;
      }
      if (product.needsVerification) {
        msg += `\n⚠️ Sujeto a verificación de disponibilidad`;
      }
      return msg;
    }

    // Default compact line requested: "Nombre — $precio efectivo / $precio tarjeta"
    let line = `${product.name} — ${cashStr} efvo / ${cardStr} tarjeta`;
    if (product.note) {
      line += ` (${product.note})`;
    }
    return line;
  };

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const text = getWhatsAppMessage();
    navigator.clipboard.writeText(text);
    setCopied(true);
    onCopied(text);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const text = getWhatsAppMessage();
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div
      className={`relative bg-white rounded-xl border transition-all p-4 flex flex-col justify-between hover:shadow-md ${
        product.needsVerification
          ? 'border-amber-300 bg-amber-50/20'
          : 'border-slate-200 hover:border-slate-300'
      }`}
    >
      <div>
        {/* Unboxed Metadata (Category · Brand) - Zero-Pill Rule */}
        <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5 font-medium">
          <span className="text-slate-700">{product.category}</span>
          {product.brand && (
            <>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-900 font-semibold">{product.brand}</span>
            </>
          )}
        </div>

        {/* Product Name */}
        <h3 className="text-sm sm:text-base font-semibold text-slate-900 leading-snug mb-2">
          {product.name}
        </h3>

        {/* Note if present */}
        {product.note && (
          <p className="text-xs text-blue-700 bg-blue-50/80 rounded-md px-2 py-1 mb-2.5 inline-block font-medium">
            📌 {product.note}
          </p>
        )}

        {/* Verification warning tag if peach color */}
        {product.needsVerification && (
          <div className="flex items-center gap-1.5 text-xs text-amber-800 bg-amber-100/80 rounded-md px-2 py-1 mb-3">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="font-medium">⚠ Verificar disponibilidad con proveedor</span>
          </div>
        )}
      </div>

      {/* Pricing Module & WhatsApp Action */}
      <div className="pt-3 border-t border-slate-100 mt-2 space-y-3">
        {/* Prices Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Cash / Transfer Price */}
          {(settings.priceDisplayMode === 'cash' || settings.priceDisplayMode === 'both') && (
            <div className="bg-emerald-50/60 rounded-lg p-2 border border-emerald-100/80">
              <span className="text-[11px] font-medium text-emerald-800 flex items-center gap-1">
                <Banknote className="w-3 h-3 text-emerald-600" />
                Efectivo / Transf.
              </span>
              <div className="text-sm sm:text-base font-bold text-emerald-950 font-mono tabular-nums mt-0.5">
                {formatCurrency(product.cashPrice)}
              </div>
              {settings.profitMarginPercent > 0 && (
                <div className="text-[10px] text-emerald-700 font-medium mt-0.5">
                  Venta: <strong className="font-mono">{formatCurrency(sellingPrice)}</strong>
                </div>
              )}
            </div>
          )}

          {/* Card Price */}
          {(settings.priceDisplayMode === 'card' || settings.priceDisplayMode === 'both') && (
            <div className="bg-slate-50 rounded-lg p-2 border border-slate-200">
              <span className="text-[11px] font-medium text-slate-700 flex items-center gap-1">
                <CreditCard className="w-3 h-3 text-slate-500" />
                Tarjeta ({settings.cardSurchargePercent}%)
              </span>
              <div className="text-sm sm:text-base font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                {formatCurrency(cardPrice)}
              </div>
              {settings.profitMarginPercent > 0 && (
                <div className="text-[10px] text-slate-600 font-medium mt-0.5">
                  Venta: <strong className="font-mono">{formatCurrency(sellingCardPrice)}</strong>
                </div>
              )}
            </div>
          )}
        </div>

        {/* WhatsApp Fast Copy & Share Actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition-all shadow-xs ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-900 text-white hover:bg-slate-800 active:scale-[0.98]'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>¡Copiado para WhatsApp!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-300" />
                <span>Copiar para WhatsApp</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleOpenWhatsApp}
            title="Abrir chat en WhatsApp"
            className="p-2 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
