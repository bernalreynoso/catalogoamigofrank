export interface RawProductRow {
  rowNumber: number;
  brand: string;
  name: string;
  cashPrice: number | null;
  cardPriceFormula?: string;
  note: string;
  category: string;
  // Raw style information for debugging
  cellCColorARGB?: string;
  cellCColorTheme?: number;
  cellDColorARGB?: string;
  cellDColorTheme?: number;
  cellFillARGB?: string;
}

export interface CatalogProduct {
  id: string;
  category: string;
  brand: string;
  name: string;
  normalizedKey: string;
  cashPrice: number;
  note?: string;
  needsVerification: boolean; // peach / warning color
  verificationReason?: string;
  originalRowNumber: number;
  debugColorC?: string;
  debugColorD?: string;
}

export interface OmittedProduct {
  id: string;
  category: string;
  brand: string;
  name: string;
  rawPrice: any;
  reason: 'pink_color' | 'no_price' | 'invalid_price';
  reasonText: string;
  detectedColor?: string;
  originalRowNumber: number;
}

export interface DebugRowInfo {
  rowNumber: number;
  category: string;
  brand: string;
  name: string;
  cellCRaw: any;
  cellCArgb?: string;
  cellCTheme?: number;
  cellDArgb?: string;
  cellDTheme?: number;
  cellAFill?: string;
  cellBFill?: string;
  classification: 'disponible' | 'omitido_rosa' | 'omitido_sin_precio' | 'verificar_disponibilidad' | 'categoria';
}

export interface PriceChange {
  id: string;
  category: string;
  brand: string;
  name: string;
  status: 'new' | 'removed' | 'price_up' | 'price_down' | 'unchanged';
  previousPrice?: number;
  newPrice?: number;
  priceDiff?: number;
  percentDiff?: number;
}

export interface CatalogData {
  fileName: string;
  listDate: string; // From IMPORTANTE!D2 or date of load
  parsedAt: string; // ISO date
  products: CatalogProduct[];
  omitted: OmittedProduct[];
  categories: string[];
  brands: string[];
  debugRows: DebugRowInfo[];
}

export interface AppSettings {
  cardSurchargePercent: number; // default 2%
  profitMarginPercent: number; // default 0%
  priceDisplayMode: 'cash' | 'card' | 'both';
  whatsAppFormat: 'compact' | 'detailed';
}
