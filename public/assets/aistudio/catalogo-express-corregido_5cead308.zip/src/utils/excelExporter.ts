import ExcelJS from 'exceljs';
import { CatalogData } from '../types';

export async function exportCatalogToExcel(
  data: CatalogData,
  cardSurchargePercent: number = 2,
  profitMarginPercent: number = 0
): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Catálogo Express';
  workbook.lastModifiedBy = 'Catálogo Express';
  workbook.created = new Date();
  workbook.modified = new Date();

  const darkBlueFill: ExcelJS.Fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF1B365D' }, // Dark Navy Blue
  };

  const headerFont: Partial<ExcelJS.Font> = {
    name: 'Arial',
    size: 10,
    bold: true,
    color: { argb: 'FFFFFFFF' },
  };

  const bodyFont: Partial<ExcelJS.Font> = {
    name: 'Arial',
    size: 10,
  };

  const currencyFormat = '"$"#,##0.00';

  // Líneas (bordes): fina en todas las celdas y gruesa al cambiar de categoría
  const lineThin: Partial<ExcelJS.Border> = { style: 'thin', color: { argb: 'FFBFBFBF' } };
  const lineThick: Partial<ExcelJS.Border> = { style: 'medium', color: { argb: 'FF1B365D' } };
  const applyBorders = (row: ExcelJS.Row, columnCount: number, newCategory: boolean) => {
    for (let c = 1; c <= columnCount; c++) {
      row.getCell(c).border = {
        top: newCategory ? lineThick : lineThin,
        bottom: lineThin,
        left: lineThin,
        right: lineThin,
      };
    }
  };

  // ==========================================
  // SHEET 1: "Catálogo"
  // ==========================================
  const catalogSheet = workbook.addWorksheet('Catálogo', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });

  catalogSheet.columns = [
    { header: 'Categoría', key: 'category', width: 22 },
    { header: 'Marca / Plataforma', key: 'brand', width: 18 },
    { header: 'Producto', key: 'name', width: 44 },
    { header: 'Precio efectivo / transferencia', key: 'cashPrice', width: 26 },
    { header: 'Precio tarjeta', key: 'cardPrice', width: 22 },
    { header: 'Nota', key: 'note', width: 28 },
  ];

  // Style Header Row
  const headerRow1 = catalogSheet.getRow(1);
  headerRow1.height = 26;
  headerRow1.eachCell((cell) => {
    cell.fill = darkBlueFill;
    cell.font = headerFont;
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = { top: lineThin, bottom: lineThin, left: lineThin, right: lineThin };
  });

  const surchargeMultiplier = 1 + cardSurchargePercent / 100;
  // Format multiplier string for formula (e.g. 1.02)
  const multiplierStr = surchargeMultiplier.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');

  let prevCategory: string | null = null;
  data.products.forEach((prod, index) => {
    const rowIdx = index + 2;
    const row = catalogSheet.addRow({
      category: prod.category,
      brand: prod.brand || '-',
      name: prod.name,
      cashPrice: prod.cashPrice,
      // Card price formula: =D{row}*1.02
      cardPrice: { formula: `D${rowIdx}*${multiplierStr}`, result: prod.cashPrice * surchargeMultiplier },
      note: prod.note || (prod.needsVerification ? '⚠ Verificar disponibilidad' : ''),
    });

    row.font = bodyFont;

    // Currency formatting
    const cellD = row.getCell(4);
    const cellE = row.getCell(5);
    cellD.numFmt = currencyFormat;
    cellE.numFmt = currencyFormat;
    cellD.alignment = { horizontal: 'right', vertical: 'middle' };
    cellE.alignment = { horizontal: 'right', vertical: 'middle' };

    if (prod.needsVerification) {
      // Soft peach highlight on warning items
      row.getCell(6).font = { name: 'Arial', size: 10, italic: true, color: { argb: 'FFB45309' } };
    }

    // Categoría en negritas, texto largo con salto de línea y bordes
    row.getCell(1).font = { name: 'Arial', size: 10, bold: true };
    row.getCell(3).alignment = { vertical: 'middle', wrapText: true };
    row.getCell(6).alignment = { vertical: 'middle', wrapText: true };
    row.getCell(1).alignment = { vertical: 'middle' };
    row.getCell(2).alignment = { vertical: 'middle' };
    applyBorders(row, 6, prod.category !== prevCategory);
    prevCategory = prod.category;
  });

  // Enable AutoFilter for Sheet 1
  if (data.products.length > 0) {
    catalogSheet.autoFilter = {
      from: 'A1',
      to: `F${data.products.length + 1}`,
    };
  }

  // ==========================================
  // SHEET 2: "Notas"
  // ==========================================
  const notesSheet = workbook.addWorksheet('Notas');

  notesSheet.columns = [
    { header: 'Parámetro / Métrica', key: 'param', width: 34 },
    { header: 'Valor', key: 'value', width: 40 },
  ];

  const headerRow2 = notesSheet.getRow(1);
  headerRow2.height = 24;
  headerRow2.eachCell((cell) => {
    cell.fill = darkBlueFill;
    cell.font = headerFont;
    cell.alignment = { vertical: 'middle', horizontal: 'left' };
    cell.border = { top: lineThin, bottom: lineThin, left: lineThin, right: lineThin };
  });

  const verifiedCount = data.products.filter((p) => p.needsVerification).length;

  const notesData = [
    { param: 'Fecha de la lista (Proveedor)', value: data.listDate || 'No especificada' },
    { param: 'Recargo con tarjeta aplicado', value: `${cardSurchargePercent}% (fórmula =C*${multiplierStr})` },
    { param: 'Margen de ganancia sugerido', value: `${profitMarginPercent}%` },
    { param: 'Total de productos disponibles', value: data.products.length },
    { param: 'Productos con aviso "verificar disponibilidad"', value: verifiedCount },
    { param: 'Total de productos omitidos (sin existencia/precio)', value: data.omitted.length },
    { param: 'Nombre de archivo origen', value: data.fileName },
    { param: 'Fecha y hora de exportación', value: new Date().toLocaleString('es-MX') },
  ];

  notesData.forEach((item) => {
    const row = notesSheet.addRow(item);
    row.font = bodyFont;
    row.getCell(1).font = { name: 'Arial', size: 10, bold: true };
    row.getCell(2).alignment = { horizontal: 'left' };
    applyBorders(row, 2, false);
  });

  // ==========================================
  // SHEET 3: "Omitidos"
  // ==========================================
  const omittedSheet = workbook.addWorksheet('Omitidos', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });

  omittedSheet.columns = [
    { header: 'Categoría', key: 'category', width: 22 },
    { header: 'Marca', key: 'brand', width: 18 },
    { header: 'Producto', key: 'name', width: 44 },
    { header: 'Precio Crudo en Excel', key: 'rawPrice', width: 22 },
    { header: 'Motivo de Exclusión', key: 'reason', width: 38 },
    { header: 'Color / Detalle', key: 'color', width: 26 },
    { header: 'Fila Original', key: 'row', width: 14 },
  ];

  const headerRow3 = omittedSheet.getRow(1);
  headerRow3.height = 26;
  headerRow3.eachCell((cell) => {
    cell.fill = darkBlueFill;
    cell.font = headerFont;
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = { top: lineThin, bottom: lineThin, left: lineThin, right: lineThin };
  });

  let prevOmittedCategory: string | null = null;
  data.omitted.forEach((om) => {
    const row = omittedSheet.addRow({
      category: om.category,
      brand: om.brand || '-',
      name: om.name,
      rawPrice: om.rawPrice?.toString() || '(vacío)',
      reason: om.reasonText,
      color: om.detectedColor || (om.reason === 'pink_color' ? 'Rosa detectado' : 'Sin precio'),
      row: om.originalRowNumber,
    });
    row.font = bodyFont;
    row.getCell(3).alignment = { vertical: 'middle', wrapText: true };
    applyBorders(row, 7, om.category !== prevOmittedCategory);
    prevOmittedCategory = om.category;
  });

  if (data.omitted.length > 0) {
    omittedSheet.autoFilter = {
      from: 'A1',
      to: `G${data.omitted.length + 1}`,
    };
  }

  // ==========================================
  // Download file in browser
  // ==========================================
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  const sanitizedDate = (data.listDate || 'Catalogo')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, 25);
  const downloadName = `Catalogo_Precios_${sanitizedDate}.xlsx`;

  const downloadUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = downloadName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(downloadUrl);
}
